"use client";

import { useState } from "react";

type Prospect = {
  lane: "C" | "D";
  subtype: string;
  name?: string;
  location?: string;
  source: string;
  url: string;
  evidence: string;
  why: string;
  confidence: "high" | "medium" | "low";
  publishedAt?: string;
};

export default function Home() {
  const [items, setItems] = useState<Prospect[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function scout() {
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/scout");
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Scout failed");
      setItems(data.prospects);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Scout failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main>
      <header>
        <div>
          <p className="eyebrow">TGG HUB</p>
          <h1>Prospect Scout</h1>
          <p className="muted">Find public evidence of actual web-development opportunities.</p>
        </div>
        <button onClick={scout} disabled={loading}>
          {loading ? "Scouting..." : "Run Scout"}
        </button>
      </header>

      {error && <div className="error">{error}</div>}

      <section className="stats">
        <div><strong>{items.length}</strong><span>specimens</span></div>
        <div><strong>{items.filter(x => x.lane === "C").length}</strong><span>C signals</span></div>
        <div><strong>{items.filter(x => x.lane === "D").length}</strong><span>D signals</span></div>
      </section>

      <section className="list">
        {items.length === 0 ? (
          <div className="empty">Run the scout. Results will appear here.</div>
        ) : items.map((item, i) => (
          <article className="card" key={`${item.url}-${i}`}>
            <div className="topline">
              <span className={`lane lane-${item.lane}`}>{item.lane}</span>
              <span>{item.subtype}</span>
              <span>{item.confidence} confidence</span>
            </div>
            <h2>{item.name || "Unresolved identity"}</h2>
            {item.location && <p className="muted">{item.location}</p>}
            <blockquote>{item.evidence}</blockquote>
            <p>{item.why}</p>
            <div className="source">
              <span>{item.source}</span>
              <a href={item.url} target="_blank" rel="noreferrer">Open evidence →</a>
            </div>
          </article>
        ))}
      </section>
    </main>
  );
}
