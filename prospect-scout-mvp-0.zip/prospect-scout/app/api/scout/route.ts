import { NextResponse } from "next/server";
import { runScout } from "../../../src/pipeline/scout";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const prospects = await runScout();
    return NextResponse.json({
      scannedAt: new Date().toISOString(),
      count: prospects.length,
      prospects: prospects.map((p) => ({
        lane: p.lane,
        subtype: p.subtype,
        name: p.name,
        location: p.location,
        source: p.evidence.source,
        url: p.evidence.url,
        evidence: p.evidence.text.slice(0, 1000),
        why: p.why,
        confidence: p.confidence,
        publishedAt: p.evidence.publishedAt
      }))
    });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    );
  }
}
