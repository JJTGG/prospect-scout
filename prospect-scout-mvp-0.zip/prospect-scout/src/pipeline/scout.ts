import type { Evidence, Prospect } from "../types/prospect";
import { detectSignal } from "../signals/detect";
import { redditCollector } from "../collectors/reddit";
import { rssCollector } from "../collectors/rss";

export async function runScout(): Promise<Prospect[]> {
  const batches = await Promise.allSettled([
    redditCollector.collect(),
    rssCollector.collect()
  ]);

  const evidence = batches.flatMap((x) => x.status === "fulfilled" ? x.value : []);
  const qualified: Prospect[] = [];

  for (const item of evidence) {
    const signal = detectSignal(`${item.title}\n${item.text}`);
    if (!signal) continue;

    qualified.push({
      id: `prospect:${item.id}`,
      lane: signal.lane,
      subtype: signal.subtype,
      name: item.author,
      evidence: item,
      why: signal.why,
      confidence: signal.confidence
    });
  }

  return dedupeProspects(qualified);
}

function dedupeProspects(items: Prospect[]) {
  const seen = new Set<string>();
  return items.filter((item) => {
    const key = normalize(item.evidence.url);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).sort((a, b) => {
    const confidence = { high: 3, medium: 2, low: 1 };
    return confidence[b.confidence] - confidence[a.confidence];
  });
}

function normalize(url: string) {
  return url.toLowerCase().replace(/\/$/, "").replace(/[?#].*$/, "");
}
