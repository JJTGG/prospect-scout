import type { Evidence } from "../types/prospect";

export interface Collector {
  name: string;
  collect(): Promise<Evidence[]>;
}
