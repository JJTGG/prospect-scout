import type { Collector } from "./types";
import type { Evidence } from "../types/prospect";

const queries = [
  "looking for web developer",
  "need web developer",
  "need website",
  "order whatsapp",
  "take orders manually",
  "google form orders"
];

export const redditCollector: Collector = {
  name: "reddit",
  async collect() {
    const out: Evidence[] = [];

    for (const query of queries) {
      const url = `https://www.reddit.com/search.json?q=${encodeURIComponent(query)}&sort=new&limit=25`;
      const res = await fetch(url, {
        headers: { "User-Agent": "prospect-scout/0.1 public-discovery" },
        next: { revalidate: 300 }
      });

      if (!res.ok) continue;
      const json = await res.json();

      for (const child of json?.data?.children ?? []) {
        const d = child?.data;
        if (!d?.permalink) continue;

        out.push({
          id: `reddit:${d.id}`,
          source: "Reddit",
          url: `https://www.reddit.com${d.permalink}`,
          title: d.title || "",
          text: `${d.title || ""}\n${d.selftext || ""}`.trim(),
          publishedAt: d.created_utc ? new Date(d.created_utc * 1000).toISOString() : undefined,
          discoveredAt: new Date().toISOString(),
          author: d.author || undefined
        });
      }
    }

    return dedupe(out);
  }
};

function dedupe(items: Evidence[]) {
  return [...new Map(items.map((x) => [x.id, x])).values()];
}
