import type { Collector } from "./types";
import type { Evidence } from "../types/prospect";

const feeds = [
  "https://www.reddit.com/r/forhire/new/.rss",
  "https://www.reddit.com/r/freelance/new/.rss"
];

export const rssCollector: Collector = {
  name: "rss",
  async collect() {
    const results: Evidence[] = [];

    for (const feed of feeds) {
      try {
        const res = await fetch(feed, {
          headers: { "User-Agent": "prospect-scout/0.1 public-discovery" },
          next: { revalidate: 300 }
        });
        if (!res.ok) continue;

        const xml = await res.text();
        const entries = [...xml.matchAll(/<entry>([\s\S]*?)<\/entry>/gi)];

        for (const match of entries) {
          const block = match[1];
          const title = clean(tag(block, "title"));
          const link = (block.match(/<link[^>]+href="([^"]+)"/i)?.[1]) || "";
          const content = clean(tag(block, "content"));
          const id = clean(tag(block, "id")) || link;
          if (!link || !id) continue;

          results.push({
            id: `rss:${id}`,
            source: feed.includes("forhire") ? "Reddit r/forhire RSS" : "Reddit r/freelance RSS",
            url: link,
            title,
            text: `${title}\n${content}`.trim(),
            publishedAt: clean(tag(block, "published")) || undefined,
            discoveredAt: new Date().toISOString()
          });
        }
      } catch {}
    }

    return [...new Map(results.map((x) => [x.id, x])).values()];
  }
};

function tag(xml: string, name: string) {
  return xml.match(new RegExp(`<${name}[^>]*>([\\\\s\\\\S]*?)</${name}>`, "i"))?.[1] || "";
}

function clean(value: string) {
  return value.replace(/<[^>]*>/g, " ").replace(/&amp;/g, "&").replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/\\s+/g, " ").trim();
}
