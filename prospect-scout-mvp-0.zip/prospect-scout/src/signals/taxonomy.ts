export const SIGNAL_TAXONOMY = {
  C: [
    "C1_manual_ordering",
    "C2_dm_whatsapp_ordering",
    "C3_manual_booking",
    "C4_forms_spreadsheets",
    "C5_repeated_questions",
    "C6_catalogue_payment_friction",
    "C7_explicit_web_request",
    "C8_event_launch",
    "C9_manual_workflow",
    "C10_custom_software_request"
  ],
  D: [
    "D1_web_developer",
    "D2_technical_partner",
    "D3_agency_overflow",
    "D4_white_label",
    "D5_outsourcing",
    "D6_freelancer_collaboration",
    "D7_client_project_developer",
    "D8_design_marketing_agency",
    "D9_contractor_freelance_developer"
  ]
} as const;
