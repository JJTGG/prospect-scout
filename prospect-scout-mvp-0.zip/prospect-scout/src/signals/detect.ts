import type { Lane, SignalSubtype } from "../types/prospect";

type Detection = {
  lane: Lane;
  subtype: SignalSubtype;
  why: string;
  confidence: "high" | "medium" | "low";
};

const rules: Array<{ lane: Lane; subtype: SignalSubtype; patterns: RegExp[]; why: string }> = [
  { lane: "D", subtype: "D1_web_developer", patterns: [/looking for (a )?web developer/i, /need (a )?web developer/i, /hire (a )?web developer/i, /hiring.*web developer/i], why: "Explicit request for web-development capacity." },
  { lane: "D", subtype: "D2_technical_partner", patterns: [/technical partner/i, /development partner/i, /tech partner/i], why: "Explicit search for a technical/development partner." },
  { lane: "D", subtype: "D3_agency_overflow", patterns: [/overflow work/i, /overflow development/i, /too much development work/i], why: "Evidence of development capacity pressure." },
  { lane: "D", subtype: "D4_white_label", patterns: [/white[- ]label.*(development|developer)/i, /(development|developer).*white[- ]label/i], why: "Explicit white-label development need." },
  { lane: "D", subtype: "D5_outsourcing", patterns: [/outsourc(e|ing).*web/i, /outsource.*development/i], why: "Explicit outsourcing signal for web development." },
  { lane: "D", subtype: "D6_freelancer_collaboration", patterns: [/collaborat(e|ion).*developer/i, /freelance developer/i], why: "Explicit developer/freelancer collaboration signal." },
  { lane: "D", subtype: "D7_client_project_developer", patterns: [/client.*(needs|need).*developer/i, /client project.*developer/i], why: "A client project is explicitly seeking development capacity." },
  { lane: "D", subtype: "D8_design_marketing_agency", patterns: [/design agency.*developer/i, /marketing agency.*developer/i, /agency.*need.*developer/i], why: "Agency-side evidence of a development requirement." },
  { lane: "D", subtype: "D9_contractor_freelance_developer", patterns: [/contract.*web developer/i, /freelance.*web developer/i], why: "Explicit contractor/freelance web-development request." },
  { lane: "C", subtype: "C2_dm_whatsapp_ordering", patterns: [/(order|orders).*whatsapp/i, /whatsapp.*(order|orders)/i, /dm.*to order/i], why: "Ordering is being handled through WhatsApp/DM rather than a dedicated web flow." },
  { lane: "C", subtype: "C1_manual_ordering", patterns: [/take.*orders.*manually/i, /orders.*manually/i, /manual.*orders/i], why: "Manual order handling is explicitly described." },
  { lane: "C", subtype: "C3_manual_booking", patterns: [/book.*manually/i, /booking.*manually/i, /appointments.*manually/i], why: "Booking/appointment handling is explicitly manual." },
  { lane: "C", subtype: "C4_forms_spreadsheets", patterns: [/google form/i, /spreadsheet.*order/i, /spreadsheet.*booking/i], why: "A form/spreadsheet is being used as the operational interface." },
  { lane: "C", subtype: "C7_explicit_web_request", patterns: [/need.*website/i, /looking for.*website/i, /need.*web app/i, /looking for.*web app/i, /need.*online store/i], why: "Explicit request for a website or web product." },
  { lane: "C", subtype: "C10_custom_software_request", patterns: [/need.*custom software/i, /need.*system built/i, /looking for.*system/i], why: "Explicit custom software/system requirement." },
  { lane: "C", subtype: "C9_manual_workflow", patterns: [/we currently.*manually/i, /currently.*manual/i, /doing.*manually/i], why: "Public evidence of a manual workflow that may be productizable." }
];

export function detectSignal(text: string): Detection | null {
  for (const rule of rules) {
    if (rule.patterns.some((p) => p.test(text))) {
      return { ...rule, confidence: "high" };
    }
  }
  return null;
}
