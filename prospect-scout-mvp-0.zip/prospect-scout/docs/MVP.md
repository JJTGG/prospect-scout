# MVP-0

## What works

- Reddit public JSON discovery
- Reddit RSS discovery
- C/D signal taxonomy
- deterministic signal extraction
- evidence-first prospect objects
- URL deduplication
- minimal review UI

## What is deliberately missing

- Supabase persistence
- scheduled jobs
- search-engine API dependency
- LLM classification
- identity enrichment
- contact enrichment
- outreach
- ML scoring

## Important design rule

Do not turn a weak keyword match into a prospect. The evidence itself must contain an observable problem or explicit capacity request.

The current detector is intentionally conservative and will produce false positives. That is expected for MVP-0; the next step is evidence verification and better entity resolution, not adding a giant keyword list.
